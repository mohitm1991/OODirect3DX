#include "Includes\InputLayout.h"

InputLayout::InputLayout(const CComPtr<ID3D11InputLayout>& inputLayout) : layout(inputLayout)
{
}