#include "Includes\Buffer.h"

Buffer::Buffer(const CComPtr<ID3D11Buffer>& buf) : buffer(buf)
{
}